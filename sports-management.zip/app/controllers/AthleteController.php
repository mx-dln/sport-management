<?php
declare(strict_types=1);

require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../helpers/auth.php';
require_once __DIR__ . '/../helpers/upload.php';
require_once __DIR__ . '/DocumentController.php';

class AthleteController
{
    public function __construct(private PDO $pdo) {}

    public function all(array $filter = []): array
    {
        $where = ['1=1'];
        $params = [];
        if (!empty($filter['sport_id'])) {
            $where[] = 'EXISTS (SELECT 1 FROM team_members tmf JOIN teams tf ON tf.id=tmf.team_id WHERE tmf.athlete_id=a.id AND tf.sport_id=?)';
            $params[] = $filter['sport_id'];
        }
        if (!empty($filter['team_id'])) {
            $where[] = 'EXISTS (SELECT 1 FROM team_members tmf WHERE tmf.athlete_id=a.id AND tmf.team_id=?)';
            $params[] = $filter['team_id'];
        }
        if (!empty($filter['athlete_status'])) {
            $where[] = 'a.athlete_status = ?';
            $params[] = $filter['athlete_status'];
        }
        if (!empty($filter['q'])) {
            $where[] = '(a.student_id LIKE ? OR a.first_name LIKE ? OR a.last_name LIKE ?)';
            $params = array_merge($params, array_fill(0, 3, '%' . $filter['q'] . '%'));
        }
        if ((current_user()['role'] ?? '') === 'coach') {
            $where[] = 'EXISTS (SELECT 1 FROM team_members tmc JOIN teams tc ON tc.id=tmc.team_id WHERE tmc.athlete_id=a.id AND tc.coach_id=?)';
            $params[] = current_user()['id'] ?? 0;
        }
        $sql = 'SELECT a.*,
                       COALESCE(NULLIF(GROUP_CONCAT(DISTINCT s.name ORDER BY s.name SEPARATOR ", "), ""), ps.name) sport_name,
                       COALESCE(NULLIF(GROUP_CONCAT(DISTINCT t.name ORDER BY t.name SEPARATOR ", "), ""), pt.name) team_name
                FROM athletes a
                LEFT JOIN team_members tm ON tm.athlete_id=a.id
                LEFT JOIN teams t ON t.id=tm.team_id
                LEFT JOIN sports s ON s.id=t.sport_id
                LEFT JOIN sports ps ON ps.id=a.sport_id
                LEFT JOIN teams pt ON pt.id=a.team_id
                WHERE ' . implode(' AND ', $where) . '
                GROUP BY a.id
                ORDER BY a.last_name, a.first_name';
        $stmt = $this->pdo->prepare($sql);
        $stmt->execute($params);
        return $stmt->fetchAll();
    }

    public function find(int $id): ?array
    {
        $stmt = $this->pdo->prepare('SELECT a.*,
                       COALESCE(NULLIF(GROUP_CONCAT(DISTINCT s.name ORDER BY s.name SEPARATOR ", "), ""), ps.name) sport_name,
                       COALESCE(NULLIF(GROUP_CONCAT(DISTINCT t.name ORDER BY t.name SEPARATOR ", "), ""), pt.name) team_name
                FROM athletes a
                LEFT JOIN team_members tm ON tm.athlete_id=a.id
                LEFT JOIN teams t ON t.id=tm.team_id
                LEFT JOIN sports s ON s.id=t.sport_id
                LEFT JOIN sports ps ON ps.id=a.sport_id
                LEFT JOIN teams pt ON pt.id=a.team_id
                WHERE a.id=?
                GROUP BY a.id');
        $stmt->execute([$id]);
        return $stmt->fetch() ?: null;
    }

    public function save(array $data, ?array $file = null): array
    {
        $id = (int)($data['id'] ?? 0);
        $fields = ['user_id','student_id','first_name','middle_name','last_name','gender','birthdate','address','course','year_level','section','contact_number','guardian_name','guardian_contact','emergency_contact','height','weight','blood_type','medical_condition','sport_id','team_id','position','athlete_status'];
        $values = [];
        foreach ($fields as $field) {
            $values[$field] = trim((string)($data[$field] ?? ''));
        }
        $namePattern = "/^[A-Za-z ]+$/";
        if ($values['first_name'] === '' || $values['last_name'] === '' || !preg_match($namePattern, $values['first_name']) || !preg_match($namePattern, $values['last_name']) || ($values['middle_name'] !== '' && !preg_match($namePattern, $values['middle_name']))) {
            return ['ok' => false, 'message' => 'Names must contain letters and spaces only. Numbers and symbols are not allowed.'];
        }

        $phonePattern = '/^\d{11}$/';
        foreach (['contact_number' => 'Contact number', 'guardian_contact' => 'Guardian contact', 'emergency_contact' => 'Emergency contact'] as $phoneKey => $phoneLabel) {
            if (!empty($values[$phoneKey]) && !preg_match($phonePattern, $values[$phoneKey])) {
                return ['ok' => false, 'message' => "{$phoneLabel} must be exactly 11 digits (e.g. 0912 3456 789)."];
            }
        }

        foreach (['user_id', 'sport_id', 'team_id'] as $nullableId) {
            $values[$nullableId] = $values[$nullableId] === '' ? null : (int)$values[$nullableId];
        }
        $values['age'] = age_from_birthdate($values['birthdate']);

        $photoSql = '';
        $photoParam = [];
        if ($file && ($file['error'] ?? UPLOAD_ERR_NO_FILE) === UPLOAD_ERR_OK) {
            $upload = upload_file($file, __DIR__ . '/../../public/uploads/profile_photos', ['jpg', 'jpeg', 'png'], 3);
            if (!$upload['ok']) {
                return $upload;
            }
            $photoSql = ', profile_photo=?';
            $photoParam[] = 'uploads/profile_photos/' . $upload['name'];
        }

        if ($id > 0) {
            $set = implode('=?, ', array_keys($values)) . '=?' . $photoSql;
            $stmt = $this->pdo->prepare("UPDATE athletes SET {$set} WHERE id=?");
            $stmt->execute([...array_values($values), ...$photoParam, $id]);
        } else {
            $keys = array_keys($values);
            if ($photoParam) {
                $keys[] = 'profile_photo';
                $values['profile_photo'] = $photoParam[0];
            }
            $stmt = $this->pdo->prepare('INSERT INTO athletes (' . implode(',', $keys) . ') VALUES (' . rtrim(str_repeat('?,', count($keys)), ',') . ')');
            $stmt->execute(array_values($values));
            $id = (int)$this->pdo->lastInsertId();
        }

        if (!empty($values['team_id']) && $id > 0) {
            $stmt = $this->pdo->prepare('INSERT IGNORE INTO team_members (team_id, athlete_id) VALUES (?, ?)');
            $stmt->execute([(int)$values['team_id'], $id]);
        }

        return ['ok' => true, 'message' => 'Athlete profile saved.', 'reload' => true];
    }

    public function resetPassword(int $id, string $defaultPassword = 'password123'): array
    {
        $athlete = $this->find($id);
        if (!$athlete) {
            return ['ok' => false, 'message' => 'Athlete profile not found.'];
        }

        if (!$this->canAccessAthlete($id)) {
            return ['ok' => false, 'message' => 'You are not allowed to reset this athlete password.'];
        }

        $userId = (int)($athlete['user_id'] ?? 0);
        if ($userId <= 0) {
            return ['ok' => false, 'message' => 'This athlete has no linked login account.'];
        }

        $stmt = $this->pdo->prepare("UPDATE users SET password=? WHERE id=? AND role='athlete'");
        $stmt->execute([password_hash($defaultPassword, PASSWORD_DEFAULT), $userId]);

        if ($stmt->rowCount() < 1) {
            return ['ok' => false, 'message' => 'Unable to reset password for this athlete account.'];
        }

        return ['ok' => true, 'message' => 'Athlete password reset to default: ' . $defaultPassword];
    }

    public function canAccessAthlete(int $athleteId): bool
    {
        $role = current_user()['role'] ?? '';
        if (in_array($role, ['admin', 'sports_coordinator'], true)) {
            return true;
        }

        if ($role !== 'coach') {
            return false;
        }

        $stmt = $this->pdo->prepare('SELECT COUNT(*) FROM team_members tm JOIN teams t ON t.id=tm.team_id WHERE tm.athlete_id=? AND t.coach_id=?');
        $stmt->execute([$athleteId, current_user()['id'] ?? 0]);
        return (int)$stmt->fetchColumn() > 0;
    }

    public function delete(int $id): array
    {
        $stmt = $this->pdo->prepare('SELECT user_id FROM athletes WHERE id=? LIMIT 1');
        $stmt->execute([$id]);
        $userId = (int)($stmt->fetchColumn() ?: 0);

        foreach ([
            'DELETE FROM athlete_documents WHERE athlete_id=?',
            'DELETE FROM medical_records WHERE athlete_id=?',
            'DELETE FROM attendance WHERE athlete_id=?',
            'DELETE FROM team_members WHERE athlete_id=?',
            'DELETE FROM competition_participants WHERE athlete_id=?',
            'DELETE FROM competition_results WHERE athlete_id=?',
            'DELETE FROM athlete_histories WHERE athlete_id=?',
        ] as $sql) {
            $stmt = $this->pdo->prepare($sql);
            $stmt->execute([$id]);
        }

        $stmt = $this->pdo->prepare('DELETE FROM athletes WHERE id=?');
        $stmt->execute([$id]);

        if ($userId > 0) {
            $stmt = $this->pdo->prepare('DELETE FROM users WHERE id=?');
            $stmt->execute([$userId]);
        }

        return ['ok' => true, 'message' => 'Athlete and linked records deleted.', 'reload' => true];
    }

    public function documents(int $athleteId): array
    {
        $athlete = $this->find($athleteId);
        $sportId = !empty($athlete['sport_id']) ? (int)$athlete['sport_id'] : null;
        $requirements = (new DocumentController($this->pdo))->requirements($sportId);
        $stmt = $this->pdo->prepare('SELECT * FROM athlete_documents WHERE athlete_id=?');
        $stmt->execute([$athleteId]);
        $docsByRequirement = [];
        foreach ($stmt->fetchAll() as $doc) {
            $docsByRequirement[(int)$doc['requirement_type_id']] = $doc;
        }
        return array_map(static function (array $requirement) use ($docsByRequirement): array {
            $doc = $docsByRequirement[(int)$requirement['id']] ?? [];
            return array_merge($requirement, $doc, [
                'title' => $requirement['title'],
                'requirement_type_id' => $requirement['id'],
            ]);
        }, $requirements);
    }
}
